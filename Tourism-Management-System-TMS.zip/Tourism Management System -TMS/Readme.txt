
Login Details for admin : 



Username : admin

Password : Test@123

Login Details for user: 



Username : anuj@gmail.com

Password : Test@123